<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <head>
    <meta charset="UTF-8">
    <title>New Folder</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

    <style type="text/css">
        body{ background-color:#7fedf0; font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
</head>
</head>

<body><p>&nbsp;</p>

<div class="dropdown">

<div align="right">
  <button class="btn btn-default dropdown-toggle" type="button" id="menu1" data-toggle="dropdown">
  Welcome <?=$_SESSION["username"];?> &nbsp; &nbsp;<br><!-- <?=$_SERVER['REMOTE_ADDR'];?> &nbsp; &nbsp;<br> -->
  <span class="caret"></span></button>
  <ul class="dropdown-menu dropdown-menu-right">
    <li><a href="reset.php">reset password</a></li>
    <li><a href="logout.php">logout</a></li> &nbsp; &nbsp;
  </ul>
</div>
</div><br>

<div align="center">
<table class= "table table-striped">
<tbody>
<tr align = "center">
<td>
  <button type="button" name="new_folder" id="new_folder" class="btn btn-success" onclick="window.location.href='newfolder.php'">New Folder</button></td>
    <td><button type="button" name="upload" id="upload" class="btn btn-success" onclick="window.location.href='upload.php'">Upload</button></td>
  <td><button type="button" name="shared" id="shared" class="btn btn-success">Shared Files</button>
</td></table></div></tr>
</tbody>

<div class="container">
  <h2>Title</h2>
  <form class="form-horizontal">
    <div class="form-group">
      <label class="control-label col-sm-2" for="Title">Title</label>
      <div class="col-sm-10"></div>
      <input type="text" class="form-control" id="title" placeholder="Create new folder" name="title">
    </div>

  	<div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-default">Submit</button>
      </div>
    </div>

  </form>
</div>
</body></html>




<?php

include("connect.php");
include("newfolder.php");




function makeDirectory($new_path, $mode)
{
	
	if(isset ($_POST['submit']))
	{ 	if (!file_exists($new_path))
		{
	        mkdir($new_path,$mode, true);
			$Create = $_POST['Create'];
			echo $Create;
	
			$sql = "INSERT INTO folder('folder_name')VALUES('$Create')";
	
			

			  if(mysqli_query($conn,$sql))
      		{
        		echo "File Uploaded";
      		}
      			else{
       			 echo "Error";
      			}
		}
	}
}
$new_path = 'bobo';
$mode = 0777;

makeDirectory($new_path, $mode);

?>